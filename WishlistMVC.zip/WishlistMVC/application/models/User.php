<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Model {
    public function create($post){    
        $data = array(            
            'name' => ucwords(strtolower($post['name'])),
            'username' => strtolower($post['username']),          
            'password' => sha1(md5(ucwords('!2()C!<'.$post['password'])).'!2()C!<'),
            'date_hired' => $post['date_hired'],
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        return $this->db->insert('users', $data);
    }
//VALIDATIONS
    public function validate($post){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[3]');       
        $this->form_validation->set_rules('username','Username','trim|required|is_unique[users.username]');
        $this->form_validation->set_rules('password','Password','trim|required|min_length[8]|matches[confirm_password]');
        $this->form_validation->set_rules('confirm_password','Confirm Password','trim|required');
        $this->form_validation->set_rules('date_hired','Date Hired','trim|required');
        
        if($this->form_validation->run()){
            return "valid";
        } else {
            return array(validation_errors());
        }       
    }

    public function find($post){
        $password  = sha1(md5(ucwords('!2()C!<'.$post['login_password'])).'!2()C!<');   
        $post['login_password']= md5($post['login_password']);   
        return $this->db->get_where('users', array('username'=> $post['login_username'], 'password' => $password))->row_array();            
    }

    public function find_by_user_id($user_id){       
       return $this->db->get_where('users', array('id' => $user_id))->row_array();
    }

    
}