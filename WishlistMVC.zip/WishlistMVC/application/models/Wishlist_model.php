<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wishlist_model extends CI_Model {
    public function create($post){
        $current_user = $this->db->get_where('users', array('id' => $this->session->userdata('id')))->row_array();
        $this->db->query('SET FOREIGN_KEY_CHECKS = 0');

        $wish = array(
            'creator' => $current_user['id'],
            'item' => $post['item'],
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );
        $this->db->insert('wishes', $wish);
        $current_item = $this->db->query('SELECT * FROM wishes ORDER BY created_at DESC')->result_array();
        
        $data = array(
            'user_id' => $current_user['id'],
            'wish_id' => $current_item[0]['id'],
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        return $this->db->insert('users_wishes', $data);
    }

    public function validate_item($post){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('item', 'Item', 'trim|required|min_length[3]');      
   
        if($this->form_validation->run()){
            return "valid"; 
        } else {
            return array(validation_errors());
        }       
    }

    public function find_items_by_user_id($user_id){
        $this->db->select('users_wishes.id as list_id, users_wishes.user_id as user_id, users_wishes.wish_id as wish_id, 
                        users_wishes.created_at as created_at, users_wishes.updated_at as updated_at, users.name as name, 
                        users.date_hired as date_hired, wishes.creator as creator, wishes.item as item')
                ->from('users_wishes')
                ->join('users', 'users_wishes.user_id = users.id')
                ->join('wishes', 'users_wishes.wish_id = wishes.id')
                ->where('users_wishes.user_id', $user_id);
        $query = $this->db->get();
        $user_data =  $query->result_array();
        $query->free_result();
        return $user_data;
    }

    public function find_others_items($user_id){
        $this->db->select()
                ->from('users_wishes')
                ->join('users','users_wishes.user_id = users.id')
                ->join('wishes','users_wishes.wish_id = wishes.id')
                ->where("users_wishes.user_id !=", $user_id)
                ->where("wishes.creator !=", $user_id);
        $query = $this->db->get();  
        $others_items =  $query->result_array();
        $query->free_result();
        return $others_items;
    }

    public function add_to_my_wishlist($item_id){
        $current_item = $this->db->get_where('wishes', array('id' => $item_id))->row_array();
        
        $item_data = array(
            'user_id' => $this->session->userdata('id'),
            'wish_id' =>  $item_id,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );        
        return $this->db->insert('users_wishes', $item_data);
    }

    public function delete($item_id){
        $this->db->query('SET FOREIGN_KEY_CHECKS = 0');
        return $this->db->delete('wishes', array('id' => $item_id));
    }

    public function remove($item_id){
        $this->db->query('SET FOREIGN_KEY_CHECKS = 0');
        return $this->db->delete('users_wishes', array('id' => $item_id));
    }

    public function get_wish_info($item_id){
        return $this->db->query('SELECT * FROM wishes JOIN users_wishes ON wishes.id = users_wishes.wish_id JOIN users ON users_wishes.user_id = users.id WHERE wishes.id = ?', array($item_id))->row_array();
        $this->db->select()
                ->from('wishes')
                ->join('users_wishes','wishes.id = users_wishes.wish_id')
                ->join('users','users_wishes.user_id = users.id')
                ->where("wishes.id", $item_id);
        $query = $this->db->get();  
        $wish_info =  $query->row_array();
        $query->free_result();
        return $wish_info;
    }

    public function get_other_who_added_this_item($item_id){
        $current_user_id = $this->session->userdata('id');
        return $this->db->query('SELECT * FROM users_wishes JOIN users ON users_wishes.user_id = users.id WHERE users_wishes.wish_id = ? AND NOT users_wishes.user_id = ?', array($item_id, $current_user_id))->result_array();
    }
}