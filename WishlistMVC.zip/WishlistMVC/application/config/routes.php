<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'main';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['register'] = 'main/register';
$route['login'] = 'main/login';
$route['registration_success'] = 'main/registration_successful';
$route['wishlists'] = 'wishlists/index';
$route['create_new'] ='wishlists/create_new';
$route['create'] = 'wishlists/create';
$route['logout'] = 'main/logout';
$route['add_to_my_wishlist/(:any)'] = 'wishlists/add_to_my_wishlist/$1';
$route['delete/(:any)'] = 'wishlists/delete_created_item/$1';
$route['remove/(:any)'] = 'wishlists/remove_added_item_from_others/$1';
$route['wish_info/(:any)'] = 'wishlists/wish_info/$1';

