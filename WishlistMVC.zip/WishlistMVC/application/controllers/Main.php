<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('User_model');	
	}

	public function index()
	{
		if(!empty($this->session->userdata('is_logged_in')))
		{
			redirect('/wishlists');
		} else {
			$this->load->view('index');
		}
	}

	public function sign_in(){
		$this->load->view('sign_in');
	}

	public function registration_page(){		
		$this->load->view('registration_page');
	}

	public function register(){			
		$result = $this->User_model->validate($this->input->post());

		if($result === "valid"){
			$id = $this->User_model->create($this->input->post());		
			redirect('registration_success');	
		} else {
			$errors = array(validation_errors());
			$this->session->set_flashdata('errors', $errors);
			$this->load->view('index', array('errors' => $this->session->flashdata('errors')));
		}
	}
	
	public function registration_successful(){		
		echo "Welcome! Registration was successful!";
		echo "<br><a href='/'>Go back to Main</a>";
	}
	
	public function login(){
		$result = $this->User_model->find($this->input->post());
		   
	   	if($result){				
			$_POST['password'] = '!F(O!R!B!I!D!D!E!N';	
			$current_user = array(
				'id' => $result['id'],
				'name' => $result['name'],
				'username' => $result['username'],
				'date_hired' => $result['date_hired'],
				'is_logged_in' => true		
			);
			$this->session->set_userdata($current_user);
			redirect('/wishlists');
	   	} else {
			$errors[] = '<p>Invalid username or password!</p>';
			$this->session->set_flashdata('errors', $errors);
			$this->load->view('index', array('errors' => $this->session->flashdata('errors')));	
	  	}
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect("/");
	}
}
