<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wishlists extends CI_Controller {
    public function __construct()
    {
        parent::__construct();     
        $this->load->model('User_model');
        $this->load->model('Wishlist_model');
    }

    public function index(){
        if(!empty($this->session->userdata('is_logged_in'))){           
            $my_items = $this->Wishlist_model->find_items_by_user_id($this->session->userdata('id'));
            $other_items = $this->Wishlist_model->find_others_items($this->session->userdata('id'));
        
            $this->load->view('my_wish_list',array('my_items'=> $my_items, 'other_items' => $other_items));  
        }
        else
        {
            redirect('/');
        }
    }

    public function create_new(){      
        $this->load->view('add_new');
    }

    public function create(){      
        $result = $this->Wishlist_model->validate_item($this->input->post());
           
		if($result === "valid"){
			$id = $this->Wishlist_model->create($this->input->post());		
			redirect('/wishlists');
		} else {
			$errors = array(validation_errors());
			$this->session->set_flashdata('errors', $errors);
			$this->load->view('add_new', array('errors' => $this->session->flashdata('errors')));
		}
    }

    public function add_to_my_wishlist($item_id){
        $add_other_item = $this->Wishlist_model->add_to_my_wishlist($item_id);
        redirect('/wishlists');
    }

    public function delete_created_item($item_id){
        $this->Wishlist_model->delete($item_id);
        redirect('/wishlists');
    }

    public function remove_added_item_from_others($item_id){
        $this->Wishlist_model->remove($item_id);
        redirect('/wishlists');
    }

    public function wish_info($item_id){
        $wish_info = $this->Wishlist_model->get_wish_info($item_id);
        $others_who_added_this_item = $this->Wishlist_model->get_other_who_added_this_item($item_id);
        $this->load->view('wish_info', array('wish_info'=> $wish_info, 'others'=> $others_who_added_this_item));
    }
}