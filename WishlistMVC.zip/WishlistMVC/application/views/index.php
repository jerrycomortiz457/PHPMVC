<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login/Registration</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <style>  
        *{
            /* outline: 1px dashed lawngreen;   */
        } 
        #errors{
            width: 400px;
            font-size:15px;
            color: red;
            line-height: .3em;
            margin-left: 13%;
        }
        #header h1{
           margin-left: 14%;
           text-shadow: 0px 2px 1px #0069D9;
        } 

        h3{ 
            text-shadow: 0px 1px 1px #0069D9;
        }

    </style>
</head>
<body>   
    <div id="header">
            <h1>Welcome to Wishlist App!</h1>  
    </div>

    <div id="errors">
        <?php    
                if(!empty($errors)){
            ?>
            <div id="errors">
                <?php
                    foreach($errors as $error){
                        echo "<p>{$error}</p>";
                    }
                ?>
            </div>
        <?php }?>
    </div>
  
    
    <div class="containter w-25" style="top: 65px; margin-top: 10px; margin-left: 284px; display: inline-table;">    
        <h3>Registration</h3>         
        
        <form action="register" method="post">     
            <label for="name" class="col-sm col-form-label d-table">Name</label>
            <div class="col-sm">
                <input type="text" class="form-control" id="name" name="name" placeholder="Name">
            </div>           
            <label for="username" class="col-sm col-form-label d-table">Username</label>
            <div class="col-sm">
                <input type="text" class="form-control" id="username" name="username" placeholder="Username">
            </div>
            <label for="password" class="col-sm col-form-label d-table">Password</label>
            <div class="col-sm">
                <input type="password" class="form-control" id="password" name="password"placeholder="Password" aria-describedby="passwordHelpInline">
            </div>
            <small id="passwordHelpInline" class="text-muted ml-3">
                Must be at least 8 characters long.
            </small>           
            <label for="confirm_password" class="col-sm col-form-label d-table">Confirm Password</label>
            <div class="col-sm">
                <input type="password" class="form-control" id="confirm_password" name="confirm_password"placeholder="Retype Password" aria-describedby="passwordHelpInline">
            </div>
            <label for="date_hired" class="col-sm col-form-label d-table">Date Hired</label>
            <div class="col-sm">
                <input type="date" class="form-control" id="date_hired" name="date_hired">
            </div>
            <input type="submit" value="Register" class="btn btn-primary position-relative mt-3" style="left: 80%;">
        </form> 
    </div>    

    <div class="containter w-25" style="top: 65px; margin-top: 10px; margin-left: 284px; display: inline-table;">    
        <h3>Login</h3>        
        
        <form action="login" method="post"> 
            <label for="login_username" class="col-sm col-form-label d-table">Username</label>
            <div class="col-sm">
                <input type="text" class="form-control" id="login_username" name="login_username" placeholder="Username">
            </div>
            <label for="login_password" class="col-sm col-form-label d-table">Password</label>
            <div class="col-sm">
                <input type="password" class="form-control" id="login_password" name="login_password"placeholder="Password" aria-describedby="passwordHelpInline">
            </div>
    
            <button type="submit" class="btn btn-primary position-relative mt-3" style="left: 81%">Submit</button>
        </form>           
    </div> 

</body>

</html>