<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create Item</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <style>
        *{
            /* outline: 1px dashed lawngreen; */
        }
        #errors{
            width: 500px;
            font-size:15px;
            color: red;
            line-height: 0em;   
            margin-left: 10px;
        }

        #header_btn a{
            display: inline;
        }   
    </style>
</head>
<body>   
    <div id="header_btn" class="container mt-5">
        <a class="btn btn-primary" href="/" role="button" style="margin-left: 81%;">Home</a>
        <a class="btn btn-primary" href="/logout" role="button" style="margin-left: 20px;">Logout</a>
    </div>

    <div class="containter w-25" style="top: 65px; margin-top: 70px; margin-left: 284px; display: inline-table;">    
        <h3>Create a New Wish List Item</h3>         
        <?php    
            if(!empty($errors)){
        ?>
        <div id="errors">
            <?= "<p>$errors[0]</p>"?>
        </div>
        <?php }?>
        <form action="create" method="post">     
            <label for="item" class="col-sm col-form-label d-table">Item/Product</label>
            <div class="col-sm">
                <input type="text" class="form-control" id="item" name="item" placeholder="Create item/product">
            </div>           
    
            <input type="submit" value="Create Item" class="btn btn-primary position-relative mt-3" style="left: 74%;">
        </form> 
    </div>    

     

</body>

</html>