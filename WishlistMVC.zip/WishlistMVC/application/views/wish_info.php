<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?=$wish_info['item']?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
 
</head>
<body>
<div id="header_btn" class="container mt-5">
        <a class="btn btn-primary" href="/" role="button" style="margin-left: 81%;">Home</a>
        <a class="btn btn-primary" href="/logout" role="button" style="margin-left: 20px;">Logout</a>
    </div> 
    <div class="containter w-75" style="top: 65px; margin: 30px auto 0px auto;">    
    <h3><?=$wish_info['item']?></h3>
    
    <h6 class="mt-5">Users who added this product/item under their wishlist:</h6>
    <?php 
        if(!empty($others)){
            foreach($others as $other){
                echo "<p style='font-style: italic;'>{$other['name']}</p>";
            }
        } else {
            echo "<p style='font-style: italic;'>No one added this product/item on their list yet.</p>";
        }
    ?>
</body>
</html>