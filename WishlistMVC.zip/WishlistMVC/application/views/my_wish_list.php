<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>My Wish List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <style>
        *{
            /* outline: 1px dashed lawngreen; */
        }
        #table_title h3{
            display: inline;  
            vertical-align: top;
        }
        #add_new_btn{
          margin-left: 80.6%;
        }
        a{
            color: #8BCFF6;
        }
    </style>
</head>
<body>
    <div id="header_btn" class="container mt-3">      
        <a class="btn btn-primary" href="/logout" role="button" style="margin-left: 107%;">Logout</a>
    </div>
        
    <div class="containter w-75" style="top: 65px; margin: 30px auto 0px auto;">    
        <h1>Hello, <?= $this->session->userdata('name')?>!</h1>  
        <div id="table_title">
            <h3>Your Wish List:</h3>    
        </div>
        
        <table class="table table-hover table-dark mt-2">
           
            <thead>
                <tr>
                <th scope="col">Item</th>
                <th scope="col">Name</th>
                <th scope="col">Date Added</th>
                <th scope="col">Action</th>                                 
            </thead>
            <tbody>
            <?php
                if(!empty($my_items)){
                    foreach($my_items as $my_item){
                        $created_at = date('M dS Y', strtotime($my_item['created_at']));
                        echo "<tr>                           
                        <td><a href='/wish_info/{$my_item['wish_id']}'>{$my_item['item']}</a></td>
                        <td>{$my_item['name']}</td>
                        <td>{$created_at}</td>
                        ";
                        if($my_item['creator'] == $this->session->userdata('id')){
                            echo  "<td><a href='/delete/{$my_item['wish_id']}'>Delete</a></td>";
                        } else {
                            echo  "<td><a href='/remove/{$my_item['list_id']}'>Remove from my Wishlist</a></td>";
                        }
                        
                    }
                }
            ?>
            </tbody>
            </table>      
        
    </div>    

        <div class="containter w-75" style="top: 65px; margin: 70px auto 0px auto;">    
        <div id="table_title">
            <h3>Other's Wish List:</h3>       
        </div>
        
        <table class="table table-hover table-dark mt-2">           
            <thead>
                <tr>
                <th scope="col">Item</th>
                <th scope="col">Name</th>
                <th scope="col">Date Added</th>
                <th scope="col">Action</th>                                 
            </thead>
            <tbody>
            
            <?php
                if(!empty($other_items)){
                foreach($other_items as $other_item){
                    $created_at = date('M dS Y', strtotime($other_item['created_at']));
                    echo "<tr>                           
                    <td><a href='/wish_info/{$other_item['wish_id']}'>{$other_item['item']}</a></td>
                    <td>{$other_item['name']}</td>
                    <td>{$created_at}</td>                   
                    <td><a href='/add_to_my_wishlist/{$other_item['id']}'>Add to my Wishlist</a></td>";                       
                }
            }
            ?>
            </tbody>
            </table>     
    </div>    

    <a class="btn btn-primary position-relavtive" href="create_new" role="button" style="margin-left: 81%;">Add New Item</a>




</body>
</html>