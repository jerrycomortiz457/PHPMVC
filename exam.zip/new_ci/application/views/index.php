<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome</title>
</head>
<body>
    <div id="wrapper">
        <div id="errors">
            <?php
                if(!empty($errors))
                {
                    echo $errors;
                }
            ?>
        </div>
        <div id="register">
            <h2>Welcome</h2>
            <h3>Register</h3>
            <form action="register" method="post">
                <label for="name">Name: <input type="text" name="name" id="name"></label>         
                <label for="username">Username: <input type="text" name="username" id="username"></label>
                <label for="password">Password: <input type="password" name="password" id="password"></label>
                <label for="">*Password should be at least 8 characters</label>
                <label for="confirm_password">Confiirm Password: <input type="password" name="confirm_password" id="confirm_password"></label>
                <input type="submit" value="Register">
            </form>
        </div>

        <div id="login">
            <h3>Login</h3>
            <form action="login" method="post">
                <label for="login_username">Username: <input type="text" name="login_username" id="login_username"></label>
                <label for="login_password">Password: <input type="password" name="login_password" id="login_password"></label>
                <input type="submit" value="Login">
            </form>
        </div>
    </div>
</body>
</html>