<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Plan</title>
</head>
<body>
    <div id="wrapper">
        <div id="header">
            <a href="/">Home</a>
            <a href="logout">Logout</a>
        </div>
        <div id="form_add_a_trip">
            <h3>Add a Trip</h3>
            <form action="add_plan" method="post">
                <label for="destination">Destination: <input type="text" name="destination" id="destination"></label>
                <label for="description">Description: <input type="text" name="description" id="description"></label>
                <label for="travel_start_date">Travel Date From: <input type="date" name="travel_start_date" id="travel_start_date"></label>
                <label for="travel_end_date">Travel Date To: <input type="date" name="travel_end_date" id="travel_end_date"></label>
                <input type="submit" value="Add">
            </form>
        </div>
    </div>
</body>
</html>