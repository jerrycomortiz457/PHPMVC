<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Destination</title>
</head>
<body>
    <div id="wrapper">
    <div id="header">
            <a href="/">Home</a>
            <a href="logout">Logout</a>
        </div>

        <div id="destination_details">
            <?php 
                 $start_date =  date_format(date_create($travel_data['travel_start_date']),'M d, Y');
                 $end_date =  date_format(date_create($travel_data['travel_end_date']),'M d, Y');
            ?>
            <h2><?=$travel_data['destination']?></h2>
            <h4>Planned By: <?=$travel_data['name']?></h4>
            <h4>Description: <?=$travel_data['plan']?></h4>
            <h4>Travel Date From: <?=$start_date?></h4>
            <h4>Travel Date To: <?=$end_date?></h4>
        </div>

        <div id="other_joining">
            
        </div>
    
    </div>
</body>
</html>