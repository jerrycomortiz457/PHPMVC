<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Travel Dashboard</title>
</head>
<body>
    <div id="wrapper">        
        <div id="header">            
            <a href='logout'>Logout</a>
        </div>
        <div id="welcome">
            <h1>Hello, <?=$user_data['name']?>!</h1>
        </div>
        <div id="trip_schedules">
            <h4>Your Trip Schedules</h4>
            <?php 
                if(!empty($plans))  
                {
                    echo   "<table>
                             <thead>
                                <tr>
                                    <th>Destination</th>
                                    <th>Travel Start Date</th>
                                    <th>Travel End Date</th>
                                    <th>Plan</th>
                                </tr>
                             </thead>
                             <tbody>";
                                                       
                            foreach($plans as $plan){                                                          
                                    $start_date =  date_format(date_create($plan['travel_start_date']),'M d, Y');
                                    $end_date =  date_format(date_create($plan['travel_end_date']),'M d, Y');
                                     echo "<tr>
                                     <td><a href='destination/{$plan['plan_id']}'>{$plan['destination']}</a></td>
                                     <td>{$start_date}</td>
                                     <td>{$end_date}</td>
                                     <td>{$plan['plan']}</td>
                                 </tr> ";
                                                                                        
                            } 
                        }                       
                                                                            
                                                                             
                            
                        
                    ?>                   
                </tbody>
            </table>
        </div>

        <div id="other_users_travel_plan">
            <h4>Other User's Travel Plans</h4>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Destination</th>
                        <th>Travel Start Date</th>
                        <th>Travel End Date</th>
                        <th>Do You Want To Join?</th>                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    //    var_dump($others_plans);
                       if(!empty($others_plans))
                       {
                           foreach($others_plans as $other_plan){
                            $start_date =  date_format(date_create($other_plan['travel_start_date']),'M d, Y');
                            $end_date =  date_format(date_create($other_plan['travel_end_date']),'M d, Y');
                            echo " <tr>
                            <td>{$other_plan['name']}</td>
                            <td><a href='#'>{$other_plan['destination']}</a></td>
                            <td>{$start_date}</td>
                            <td>{$end_date}</td>                           
                            <td><a href='/join/{$other_plan['plan_id']}'>Join</a></td>
                        </tr> ";
                           }                          
                       }
                    ?>
                  
                </tbody>
            </table>
        </div>
        <div id="add_travel_plan">
            <a href="add_plan_page">Add Travel Plan</a>
        </div>
        

    </div>
    
</body>
</html>