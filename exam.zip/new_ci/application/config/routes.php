<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'main';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['register'] = 'main/register';
$route['login'] = 'main/login';
$route['logout'] = 'main/logout';
$route['travels'] = 'travels/index';
$route['add_plan_page'] = 'travels/add_plan_page';
$route['add_plan'] = 'travels/add_plan';
$route['join/(:any)'] = 'travels/join/$1';
$route['destination/(:any)'] = 'travels/destination/$1';