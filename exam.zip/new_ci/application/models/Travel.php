<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Travel extends CI_Model{

    function get_all_plans(){
        return $this->db->query('SELECT * FROM plans ORDER BY created_at DESC')->result_array();
    }
    
    function add_plan($travel_plan){
        $this->db->query('SET FOREIGN_KEY_CHECKS = 0');
        $query = 'INSERT INTO plans(destination, travel_start_date, travel_end_date, plan, created_at, updated_at) VALUES(?,?,?,?,?,?)';
        $values = array($travel_plan['destination'], $travel_plan['travel_start_date'],$travel_plan['travel_end_date'], $travel_plan['description'], date('Y-m-d H:i:s'), date('Y-m-d H:i:s'));
        return $this->db->query($query, $values);
    }

    function add_to_users_has_plans($travel_data){
        $query = 'INSERT INTO users_has_plans(user_id, plan_id, created_at, updated_at) VALUES (?,?,?,?)';
        $values = array($travel_data['user_id'], $travel_data['plan_id'],date('Y-m-d H:i:s'), date('Y-m-d H:i:s'));
        return $this->db->query($query, $values);
    }

    function get_plan_by_user_id($user_id){
        return $this->db->query('SELECT * FROM plans WHERE plans.user_id = ?', array($user_id))->result_array();
    }

    function get_plan_by_plan_id($plan_id){
        return $this->db->query('SELECT * FROM plans JOIN users_has_plans ON plans.id = users_has_plans.plan_id JOIN users ON users_has_plans.user_id = users.id WHERE plans.id = ? ORDER BY plans.created_at = users_has_plans.created_at', array($plan_id))->row_array();
    }   

    function get_others_plans($user_id){
        return $this->db->query('SELECT * FROM users_has_plans JOIN users ON users.id = users_has_plans.user_id JOIN plans ON  users_has_plans.plan_id = plans.id WHERE NOT users_has_plans.user_id = ?', array($user_id))->result_array();
    }

    function join_user_on_plan($plan){
        $this->db->query('SET FOREIGN_KEY_CHECKS = 0');
        $query = 'INSERT INTO users_has_plans(user_id, plan_id, created_at, updated_at) VALUES(?,?,?,?)';
        $values = array($plan['user_id'], $plan['plan_id'], date('Y-m-d H:i:s'),date('Y-m-d H:i:s'));
        return $this->db->query($query, $values);

    }

    function get_all_travel_plans_by_user_id($user_id){
        return $this->db->query('SELECT * FROM travel_db.users_has_plans JOIN users ON users_has_plans.user_id = users.id JOIN plans ON users_has_plans.plan_id = plans.id WHERE users_has_plans.user_id = ?', array($user_id))->result_array();
    }


}

