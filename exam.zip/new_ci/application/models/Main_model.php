<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Main_model extends CI_Model{

    function check_username($username){
        return $this->db->query('SELECT * FROM users WHERE username = ?', array($username))->row_array();
    }

    function get_user_by_id($id){
        return $this->db->query('SELECT * FROM users WHERE users.id = ?', array($id))->row_array();
    }

    function add_user($user){
        $query = 'INSERT INTO users(name, username, password, created_at, updated_at) VALUES (?,?,?,?,?)';
        $values = array($user['name'], $user['username'], $user['password'], date('Y-m-d H:i:s'), date('Y-m-d H:i:s'));
        return $this->db->query($query, $values);
    }

    function logout(){
        $this->session->sess_destroy();
        redirect('/');
    }




}