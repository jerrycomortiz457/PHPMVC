<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Main extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->output->enable_profiler(TRUE);
	}
	public function index()
	{
		if($this->session->userdata('is_logged_in') == true)
		{			
			redirect('/travels');
		}
		else
		{
			$this->load->view('index');
		}
	}

	public function register(){
		if (isset($_POST['name'])) {
			if (preg_match('/[^a-zA-Z ]/', $_POST['name'])) {
				$this->form_validation->set_rules('name', 'Name', 'trim|required|alpha|min_length[3]');
			} else {
				$this->form_validation->set_rules('name', 'Name', 'trim|required|alpha_numeric_spaces|min_length[3]');
			}
		}

		$this->form_validation->set_rules('username', 'username', 'trim|required|alpha_numeric|min_length[3]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|min_length[8]|matches[password]');
		$check_username_in_database = $this->Main_model->check_username($_POST['username']);
		if ($this->form_validation->run() === false) {
			if ($check_username_in_database != null) {
				$this->session->set_flashdata('errors', validation_errors() . 'The username you entered is already in use.');
			} else {
				$this->session->set_flashdata('errors', validation_errors());
			}
			$this->load->view('index', array('errors' => $this->session->flashdata('errors')));
		} 
		else if ($this->form_validation->run() === true && $check_username_in_database != null) 
		{
			$this->session->set_flashdata('errors', validation_errors() . 'The username you entered is already in use.');
			$this->load->view('index', array('errors' => $this->session->flashdata('errors')));
		} 
		else if ($this->form_validation->run() === true && $check_username_in_database == null) 
		{
			$validated_username= $this->input->post('username');
			$_POST['password'] = md5('x'.$_POST['password'].'x');
			$_POST['confirm_password'] = md5('x'.$_POST['confirm_password'].'x');
			$encrypted_password = sha1(md5('z'.$_POST['password'].'z'));
			$registration_details = array(
				'name' => $this->input->post('name'),			
				'username' => $validated_username,
				'password' => $encrypted_password
			);
			// var_dump($registration_details);
			$registration = $this->Main_model->add_user($registration_details);
			echo 'Successfully registered! <br>';
			echo '<a href="main">Go back to welcome page</a>';
		}
	}

	public function login(){
		$username = $this->input->post('login_username');
		$user = $this->Main_model->check_username($username);	
		$_POST['login_password'] = md5('x'.$_POST['login_password'].'x');
		$password = sha1(md5('z'.$_POST['login_password'].'z'));	
		if($user && $user['password'] == $password)
		{
			$user_details = array(
				'user_id' => $user['id'],
				'name' => $user['name'],
				'username' => $user['username'],			
				'is_logged_in' => true
			);

			$this->session->set_userdata($user_details);	
			redirect('/');
		}
		else
		{
			$this->session->set_flashdata('errors', '<p>Invalid username or password!</p>');
			$this->load->view('index', array('errors'=> $this->session->flashdata('errors')));
		}
	}

	public function logout(){		
		$this->session->sess_destroy();
		redirect('/');
	}




}
