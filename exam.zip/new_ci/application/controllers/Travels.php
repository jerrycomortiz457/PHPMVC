<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Travels extends CI_Controller{
    public function __construct()
	{
		parent::__construct();
		$this->output->enable_profiler(TRUE);
	}

    public function index(){        
     
        // $get_plans = $this->Travel->get_plan_by_user_id($_SESSION['user_id']);
        $get_all_plans = $this->Travel->get_all_travel_plans_by_user_id($_SESSION['user_id']);
        // var_dump($get_all_plans);
        $get_others_plans = $this->Travel->get_others_plans($_SESSION['user_id']);
        // var_dump($get_others_plans);
        $get_current_plan = $this->Travel->get_all_plans();
        // var_dump($get_current_plan[0]['id']);
        $user_data = $this->session->userdata();
        $this->load->view('travel_dashboard', array('user_data'=> $user_data, 'plans' => $get_all_plans, 'others_plans' => $get_others_plans));
        
       
    }
    public function add_plan_page(){
        $this->load->view('add_plan');
    }

    public function add_plan(){
        
        // $user_id = $this->session->userdata('user_id');
        $destination = $this->input->post('destination');
        $description = $this->input->post('description');
        $travel_start_date =  $this->input->post('travel_start_date');
        $travel_end_date =  $this->input->post('travel_end_date');
        $travel_plan = array(
            // 'user_id' => $user_id,
            'destination' => $destination,
            'description' => $description,
            'travel_start_date' => $travel_start_date,
            'travel_end_date' => $travel_end_date
        );

        $add_plan = $this->Travel->add_plan($travel_plan);
        $get_current_plan = $this->Travel->get_all_plans();
        $current_plan_id = $get_current_plan[0]['id'];
        $travel_details = array(
            'user_id' => $_SESSION['user_id'],
            'plan_id' =>  $current_plan_id
        );
        $add_to_users_has_plans = $this->Travel->add_to_users_has_plans($travel_details);

        if($add_plan === TRUE)
        {
            redirect('/travels');
        }
        else
        {
            echo 'fail to add';
        }
        
    }

    public function join($plan_id){
        $get_plan = $this->Travel->get_plan_by_plan_id($plan_id);
        var_dump($get_plan);
        $user_id = $_SESSION['user_id'];
        $travel_plan = array(
            'user_id' => $user_id,
            'plan_id' => $plan_id            
        );
        $add_plan = $this->Travel->join_user_on_plan($travel_plan);
      
        redirect('/');
    }

    public function destination($id){
        $travel_data = $this->Travel->get_plan_by_plan_id($id);  

        $this->load->view('destination', array('travel_data'=>$travel_data));

    }

}